@echo off
setlocal

set "SCRIPT_DIR=%~dp0"
for %%I in ("%SCRIPT_DIR%..\..") do set "BIZHAWK_DIR=%%~fI"

start "Sound Bridge" powershell -NoExit -ExecutionPolicy Bypass -File "%SCRIPT_DIR%Data\qB4xK8nM2vRtY.ps1" -BizHawkDir "%BIZHAWK_DIR%" -SpeechFile "%SCRIPT_DIR%Data\wL5cF9pH7jXdQ.txt"
