param(
    [Parameter(Mandatory = $true)]
    [string]$BizHawkDir,

    [string]$SpeechFile = "",

    [string]$SoundCommandFile = "",

    [string]$SoundsDir = "",

    [string]$LogFile = "",

    [int]$PollMs = 120
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

# $PSScriptRoot is not available inside the param() block when the script
# is invoked with -File, so the path defaults are filled in here instead.
# Each path falls back to a $PSScriptRoot-relative location only when the
# caller didn't pass an explicit value.
if ([string]::IsNullOrEmpty($SpeechFile))       { $SpeechFile       = Join-Path $PSScriptRoot 'wL5cF9pH7jXdQ.txt' }
if ([string]::IsNullOrEmpty($SoundCommandFile)) { $SoundCommandFile = Join-Path $PSScriptRoot 'sound_bridge_command.txt' }
if ([string]::IsNullOrEmpty($SoundsDir))        { $SoundsDir        = Join-Path $PSScriptRoot 'Sounds' }
if ([string]::IsNullOrEmpty($LogFile))          { $LogFile          = Join-Path $PSScriptRoot 'sound_bridge.log' }

$bridgeMutex = $null
try {
    $createdNew = $false
    $bridgeMutex = New-Object System.Threading.Mutex($true, 'Zelda1AccessSoundBridgeSingleton', [ref]$createdNew)
    if (-not $createdNew) {
        Write-Host 'Sound bridge already running. Exiting duplicate instance.'
        exit 0
    }
} catch {
    Write-Host "Failed to acquire sound bridge mutex: $($_.Exception.Message)"
    exit 1
}

Add-Type -AssemblyName System.Speech
Add-Type -AssemblyName System
Add-Type @"
using System;
using System.IO;

public static class WavePan {
    private static short ClampSample(double value) {
        if (value > short.MaxValue) return short.MaxValue;
        if (value < short.MinValue) return short.MinValue;
        return (short)value;
    }

    public static byte[] Pan16BitPcm(byte[] input, int panPercent, int volumePercent) {
        if (input == null || input.Length < 44) {
            return input;
        }

        int channels = BitConverter.ToInt16(input, 22);
        int sampleRate = BitConverter.ToInt32(input, 24);
        int bitsPerSample = BitConverter.ToInt16(input, 34);
        int dataOffset = 44;
        if (bitsPerSample != 16 || (channels != 1 && channels != 2)) {
            return input;
        }

        double pan = Math.Max(-100.0, Math.Min(100.0, panPercent)) / 100.0;
        double volume = Math.Max(0.0, Math.Min(100.0, volumePercent)) / 100.0;
        double leftGain = pan <= 0 ? 1.0 : 1.0 - pan;
        double rightGain = pan >= 0 ? 1.0 : 1.0 + pan;

        int inputFrameSize = channels * 2;
        int sampleFrames = (input.Length - dataOffset) / inputFrameSize;
        int outputDataSize = sampleFrames * 4;

        using (var ms = new MemoryStream(44 + outputDataSize))
        using (var writer = new BinaryWriter(ms)) {
            writer.Write(System.Text.Encoding.ASCII.GetBytes("RIFF"));
            writer.Write(36 + outputDataSize);
            writer.Write(System.Text.Encoding.ASCII.GetBytes("WAVE"));
            writer.Write(System.Text.Encoding.ASCII.GetBytes("fmt "));
            writer.Write(16);
            writer.Write((short)1);
            writer.Write((short)2);
            writer.Write(sampleRate);
            writer.Write(sampleRate * 4);
            writer.Write((short)4);
            writer.Write((short)16);
            writer.Write(System.Text.Encoding.ASCII.GetBytes("data"));
            writer.Write(outputDataSize);

            for (int i = 0; i < sampleFrames; i++) {
                int frameOffset = dataOffset + (i * inputFrameSize);
                short inLeft = BitConverter.ToInt16(input, frameOffset);
                short inRight = channels == 2 ? BitConverter.ToInt16(input, frameOffset + 2) : inLeft;
                short outLeft = ClampSample(inLeft * leftGain * volume);
                short outRight = ClampSample(inRight * rightGain * volume);
                writer.Write(outLeft);
                writer.Write(outRight);
            }

            writer.Flush();
            return ms.ToArray();
        }
    }
}
"@
Add-Type @"
using System;
using System.IO;

public static class EnemySynth {
    private static short ClampSample(double value) {
        if (value > short.MaxValue) return short.MaxValue;
        if (value < short.MinValue) return short.MinValue;
        return (short)value;
    }

    public static byte[] CreateEnemy(int panPercent, double pitchScale, int volumePercent) {
        const int sampleRate = 22050;
        const int channels = 2;
        const int bitsPerSample = 16;
        const int durationMs = 130;
        int sampleFrames = (sampleRate * durationMs) / 1000;
        int outputDataSize = sampleFrames * channels * 2;
        double pan = Math.Max(-100.0, Math.Min(100.0, panPercent)) / 100.0;
        double volume = Math.Max(0.0, Math.Min(100.0, volumePercent)) / 100.0;
        double leftGain = pan <= 0 ? 1.0 : 1.0 - pan;
        double rightGain = pan >= 0 ? 1.0 : 1.0 + pan;
        double clampedPitch = Math.Max(0.35, Math.Min(2.5, pitchScale));

        using (var ms = new MemoryStream(44 + outputDataSize))
        using (var writer = new BinaryWriter(ms)) {
            writer.Write(System.Text.Encoding.ASCII.GetBytes("RIFF"));
            writer.Write(36 + outputDataSize);
            writer.Write(System.Text.Encoding.ASCII.GetBytes("WAVE"));
            writer.Write(System.Text.Encoding.ASCII.GetBytes("fmt "));
            writer.Write(16);
            writer.Write((short)1);
            writer.Write((short)channels);
            writer.Write(sampleRate);
            writer.Write(sampleRate * channels * 2);
            writer.Write((short)(channels * 2));
            writer.Write((short)bitsPerSample);
            writer.Write(System.Text.Encoding.ASCII.GetBytes("data"));
            writer.Write(outputDataSize);

            double baseFreq = 440.0 * clampedPitch;
            double overtone = 660.0 * clampedPitch;
            int delayA = (int)(sampleRate * 0.052);
            int delayB = (int)(sampleRate * 0.118);
            int delayC = (int)(sampleRate * 0.182);
            double[] tail = new double[sampleFrames];
            for (int i = 0; i < sampleFrames; i++) {
                double t = (double)i / sampleRate;
                double env = Math.Exp(-t * 18.0);
                double wobble = 1.0 + (0.02 * Math.Sin(2.0 * Math.PI * 7.0 * t));
                double toneA = Math.Sin(2.0 * Math.PI * baseFreq * wobble * t) * 0.65;
                double toneB = Math.Sin(2.0 * Math.PI * overtone * t) * 0.25 * Math.Exp(-t * 28.0);
                double pulse = Math.Sin(2.0 * Math.PI * 14.0 * t) * 0.10;
                double raw = (toneA + toneB + pulse) * env;
                if (i >= delayA) {
                    raw += tail[i - delayA] * 0.12;
                }
                if (i >= delayB) {
                    raw += tail[i - delayB] * 0.08;
                }
                if (i >= delayC) {
                    raw += tail[i - delayC] * 0.05;
                }
                tail[i] = raw;
                double sample = Math.Tanh(raw * 1.95) * 22000.0 * volume;
                short left = ClampSample(sample * leftGain);
                short right = ClampSample(sample * rightGain);
                writer.Write(left);
                writer.Write(right);
            }

            writer.Flush();
            return ms.ToArray();
        }
    }
}
"@
Add-Type @"
using System;
using System.IO;

public static class ItemSynth {
    private static short ClampSample(double value) {
        if (value > short.MaxValue) return short.MaxValue;
        if (value < short.MinValue) return short.MinValue;
        return (short)value;
    }

    public static byte[] CreateItem(int panPercent, int itemId, int volumePercent) {
        const int sampleRate = 22050;
        const int channels = 2;
        const int bitsPerSample = 16;
        const int durationMs = 145;
        int sampleFrames = (sampleRate * durationMs) / 1000;
        int outputDataSize = sampleFrames * channels * 2;
        double pan = Math.Max(-100.0, Math.Min(100.0, panPercent)) / 100.0;
        double volume = Math.Max(0.0, Math.Min(100.0, volumePercent)) / 100.0;
        double leftGain = pan <= 0 ? 1.0 : 1.0 - pan;
        double rightGain = pan >= 0 ? 1.0 : 1.0 + pan;

        double baseFreq;
        double overtoneFreq;
        double sparkleMix;
        switch (itemId) {
            case 0x00: baseFreq = 320.0; overtoneFreq = 480.0; sparkleMix = 0.06; break; // Bomb
            case 0x0F: baseFreq = 690.0; overtoneFreq = 1035.0; sparkleMix = 0.10; break; // 5 rupees
            case 0x18: baseFreq = 560.0; overtoneFreq = 840.0; sparkleMix = 0.09; break; // Rupee
            case 0x21: baseFreq = 250.0; overtoneFreq = 500.0; sparkleMix = 0.03; break; // Clock
            case 0x22: baseFreq = 760.0; overtoneFreq = 1140.0; sparkleMix = 0.08; break; // Heart
            case 0x23: baseFreq = 920.0; overtoneFreq = 1380.0; sparkleMix = 0.12; break; // Fairy
            default: baseFreq = 600.0; overtoneFreq = 900.0; sparkleMix = 0.08; break;
        }

        using (var ms = new MemoryStream(44 + outputDataSize))
        using (var writer = new BinaryWriter(ms)) {
            writer.Write(System.Text.Encoding.ASCII.GetBytes("RIFF"));
            writer.Write(36 + outputDataSize);
            writer.Write(System.Text.Encoding.ASCII.GetBytes("WAVE"));
            writer.Write(System.Text.Encoding.ASCII.GetBytes("fmt "));
            writer.Write(16);
            writer.Write((short)1);
            writer.Write((short)channels);
            writer.Write(sampleRate);
            writer.Write(sampleRate * channels * 2);
            writer.Write((short)(channels * 2));
            writer.Write((short)bitsPerSample);
            writer.Write(System.Text.Encoding.ASCII.GetBytes("data"));
            writer.Write(outputDataSize);

            for (int i = 0; i < sampleFrames; i++) {
                double t = (double)i / sampleRate;
                double env = Math.Exp(-t * 14.0);
                double swell = 1.0 - Math.Exp(-t * 80.0);
                double toneA = Math.Sin(2.0 * Math.PI * baseFreq * t) * 0.62;
                double toneB = Math.Sin(2.0 * Math.PI * overtoneFreq * t) * 0.26;
                double sparkle = Math.Sin(2.0 * Math.PI * (overtoneFreq * 1.5) * t) * sparkleMix * Math.Exp(-t * 22.0);
                double raw = (toneA + toneB + sparkle) * env * swell;
                double sample = Math.Tanh(raw * 1.9) * 19000.0 * volume;
                short left = ClampSample(sample * leftGain);
                short right = ClampSample(sample * rightGain);
                writer.Write(left);
                writer.Write(right);
            }

            writer.Flush();
            return ms.ToArray();
        }
    }
}
"@
Add-Type @"
using System;
using System.IO;

public static class StepSynth {
    private static short ClampSample(double value) {
        if (value > short.MaxValue) return short.MaxValue;
        if (value < short.MinValue) return short.MinValue;
        return (short)value;
    }

    public static byte[] CreateStep(int panPercent, int variant, double pitchScale, int volumePercent) {
        const int sampleRate = 22050;
        const int channels = 2;
        const int bitsPerSample = 16;
        const int durationMs = 42;
        int sampleFrames = (sampleRate * durationMs) / 1000;
        int outputDataSize = sampleFrames * channels * 2;
        double pan = Math.Max(-100.0, Math.Min(100.0, panPercent)) / 100.0;
        double volume = Math.Max(0.0, Math.Min(100.0, volumePercent)) / 100.0;
        double leftGain = pan <= 0 ? 1.0 : 1.0 - pan;
        double rightGain = pan >= 0 ? 1.0 : 1.0 + pan;
        int seed = 1337 + (variant * 977) + (panPercent * 17);

        using (var ms = new MemoryStream(44 + outputDataSize))
        using (var writer = new BinaryWriter(ms)) {
            writer.Write(System.Text.Encoding.ASCII.GetBytes("RIFF"));
            writer.Write(36 + outputDataSize);
            writer.Write(System.Text.Encoding.ASCII.GetBytes("WAVE"));
            writer.Write(System.Text.Encoding.ASCII.GetBytes("fmt "));
            writer.Write(16);
            writer.Write((short)1);
            writer.Write((short)channels);
            writer.Write(sampleRate);
            writer.Write(sampleRate * channels * 2);
            writer.Write((short)(channels * 2));
            writer.Write((short)bitsPerSample);
            writer.Write(System.Text.Encoding.ASCII.GetBytes("data"));
            writer.Write(outputDataSize);

            var random = new Random(seed);
            double baseFreq = (variant == 0 ? 2100.0 : 2200.0) * pitchScale;
            double overtoneFreq = (variant == 0 ? 3000.0 : 3160.0) * pitchScale;
            double gritMix = variant == 0 ? 0.12 : 0.14;
            double bodyMix = variant == 0 ? 0.16 : 0.15;
            double overtoneMix = variant == 0 ? 0.40 : 0.44;
            for (int i = 0; i < sampleFrames; i++) {
                double t = (double)i / sampleRate;
                double attack = Math.Min(1.0, i / 10.0);
                double decay = Math.Exp(-t * (variant == 0 ? 84.0 : 92.0));
                double highDecay = Math.Exp(-t * 165.0);
                double body = Math.Sin(2.0 * Math.PI * baseFreq * t) * bodyMix;
                double overtone = Math.Sin(2.0 * Math.PI * overtoneFreq * t) * overtoneMix * highDecay;
                double grit = ((random.NextDouble() * 2.0) - 1.0) * gritMix * highDecay;
                double transient = Math.Sin(2.0 * Math.PI * (variant == 0 ? 920.0 : 1020.0) * pitchScale * t) * 0.22 * Math.Exp(-t * 175.0);
                double tick = Math.Sin(2.0 * Math.PI * (variant == 0 ? 3350.0 : 3650.0) * pitchScale * t) * 0.18 * Math.Exp(-t * 310.0);
                double sample = (transient + tick + body + overtone + grit) * attack * decay * (variant == 0 ? 9800.0 : 10200.0);
                short left = ClampSample(sample * leftGain * volume);
                short right = ClampSample(sample * rightGain * volume);
                writer.Write(left);
                writer.Write(right);
            }

            writer.Flush();
            return ms.ToArray();
        }
    }
}
"@
Add-Type @"
using System;
using System.IO;

public static class BumpSynth {
    private static short ClampSample(double value) {
        if (value > short.MaxValue) return short.MaxValue;
        if (value < short.MinValue) return short.MinValue;
        return (short)value;
    }

    public static byte[] CreateBump(int panPercent, int volumePercent) {
        const int sampleRate = 22050;
        const int channels = 2;
        const int bitsPerSample = 16;
        const int durationMs = 92;
        int sampleFrames = (sampleRate * durationMs) / 1000;
        int outputDataSize = sampleFrames * channels * 2;
        double pan = Math.Max(-100.0, Math.Min(100.0, panPercent)) / 100.0;
        double volume = Math.Max(0.0, Math.Min(100.0, volumePercent)) / 100.0;
        double leftGain = pan <= 0 ? 1.0 : 1.0 - pan;
        double rightGain = pan >= 0 ? 1.0 : 1.0 + pan;
        var random = new Random(4242 + (panPercent * 19) + (volumePercent * 7));

        using (var ms = new MemoryStream(44 + outputDataSize))
        using (var writer = new BinaryWriter(ms)) {
            writer.Write(System.Text.Encoding.ASCII.GetBytes("RIFF"));
            writer.Write(36 + outputDataSize);
            writer.Write(System.Text.Encoding.ASCII.GetBytes("WAVE"));
            writer.Write(System.Text.Encoding.ASCII.GetBytes("fmt "));
            writer.Write(16);
            writer.Write((short)1);
            writer.Write((short)channels);
            writer.Write(sampleRate);
            writer.Write(sampleRate * channels * 2);
            writer.Write((short)(channels * 2));
            writer.Write((short)bitsPerSample);
            writer.Write(System.Text.Encoding.ASCII.GetBytes("data"));
            writer.Write(outputDataSize);

            for (int i = 0; i < sampleFrames; i++) {
                double t = (double)i / sampleRate;
                double progress = (double)i / sampleFrames;
                double bodyEnv = Math.Exp(-t * 24.0);
                double transientEnv = Math.Exp(-t * 165.0);
                double sweep = 1.0 - (progress * 0.28);
                double sub = Math.Sin(2.0 * Math.PI * (92.0 * sweep) * t) * 0.95;
                double body = Math.Sin(2.0 * Math.PI * (138.0 * sweep) * t) * 0.40;
                double knock = Math.Sin(2.0 * Math.PI * 360.0 * t) * 0.22 * transientEnv;
                double click = Math.Sin(2.0 * Math.PI * 920.0 * t) * 0.10 * Math.Exp(-t * 260.0);
                double grit = ((random.NextDouble() * 2.0) - 1.0) * 0.11 * transientEnv;
                double attackPunch = Math.Exp(-t * 260.0) * 0.34;
                double onset = progress < 0.009 ? (1.0 + ((0.009 - progress) * 24.0)) : 1.0;
                double raw = (sub + body + knock + click + grit + attackPunch) * bodyEnv * onset;
                double shaped = Math.Tanh(raw * 1.55);
                double sample = shaped * 22000.0 * volume;
                short left = ClampSample(sample * leftGain);
                short right = ClampSample(sample * rightGain);
                writer.Write(left);
                writer.Write(right);
            }

            writer.Flush();
            return ms.ToArray();
        }
    }
}
"@

$resolvedBizHawkDir = (Resolve-Path $BizHawkDir).Path
[Environment]::CurrentDirectory = $resolvedBizHawkDir

Add-Type @"
using System;
using System.Runtime.InteropServices;
public static class NativePath {
    [DllImport("kernel32.dll", CharSet = CharSet.Unicode, SetLastError = true)]
    public static extern bool SetDllDirectory(string lpPathName);
}
"@
[void][NativePath]::SetDllDirectory($resolvedBizHawkDir)

$nvdaDllName = @(
    'NVDAControllerClient.dll',
    'nvdaControllerClient.dll',
    'NVDAControllerClient64.dll',
    'nvdaControllerClient64.dll'
) | Where-Object { Test-Path (Join-Path $resolvedBizHawkDir $_) } | Select-Object -First 1
$tolkDll = Join-Path $resolvedBizHawkDir 'Tolk.dll'

$nvdaLoaded = $false
$tolkLoaded = $false
$tolkReady = $false

if ($nvdaDllName) {
    Add-Type @"
using System;
using System.Runtime.InteropServices;
public static class NvdaBridge {
    [DllImport("$nvdaDllName", CharSet = CharSet.Unicode)]
    public static extern int nvdaController_speakText(string text);
    [DllImport("$nvdaDllName")]
    public static extern int nvdaController_testIfRunning();
}
"@
    $nvdaLoaded = $true
}

if (Test-Path $tolkDll) {
    Add-Type @"
using System;
using System.Runtime.InteropServices;
public static class TolkBridge {
    [DllImport("Tolk.dll", CharSet = CharSet.Unicode)]
    public static extern bool Tolk_Load();
    [DllImport("Tolk.dll")]
    public static extern bool Tolk_HasSpeech();
    [DllImport("Tolk.dll")]
    public static extern bool Tolk_Unload();
    [DllImport("Tolk.dll", CharSet = CharSet.Unicode)]
    public static extern bool Tolk_Speak(string text, bool interrupt);
}
"@
    $tolkLoaded = $true
}

if ($tolkLoaded) {
    try {
        $tolkReady = [TolkBridge]::Tolk_Load()
    } catch {
        $tolkReady = $false
    }
}

$synth = $null
try {
    $synth = New-Object System.Speech.Synthesis.SpeechSynthesizer
    $synth.SetOutputToDefaultAudioDevice()
} catch {
    $synth = $null
}

$activePlayers = New-Object System.Collections.ArrayList
$activeWaveExpirations = @{}
$loopingPlayers = @{}
$lastSpeechPayload = ''
$lastSpeechSequence = -1
$lastSoundSequence = -1

function Write-BridgeLog {
    param([string]$Message)
    $timestamp = Get-Date -Format 'yyyy-MM-dd HH:mm:ss.fff'
    $line = "[$timestamp] $Message"
    Add-Content -Path $LogFile -Value $line
    Write-Host $line
}

function Speak-Bridge {
    param([string]$Text)

    if ([string]::IsNullOrWhiteSpace($Text)) {
        return
    }

    if ($nvdaLoaded) {
        try {
            if ([NvdaBridge]::nvdaController_testIfRunning() -eq 0) {
                [void][NvdaBridge]::nvdaController_speakText($Text)
                Write-BridgeLog "Spoke via NVDA: $Text"
                return
            }
        } catch {
            Write-BridgeLog "NVDA speak failed: $($_.Exception.Message)"
        }
    }

    if ($tolkLoaded -and $tolkReady) {
        try {
            if ([TolkBridge]::Tolk_HasSpeech() -and [TolkBridge]::Tolk_Speak($Text, $true)) {
                Write-BridgeLog "Spoke via Tolk: $Text"
                return
            }
        } catch {
            Write-BridgeLog "Tolk speak failed: $($_.Exception.Message)"
        }
    }

    if ($synth) {
        $synth.SpeakAsyncCancelAll()
        [void]$synth.SpeakAsync($Text)
        Write-BridgeLog "Spoke via synth: $Text"
        return
    }

    Write-BridgeLog "No speech backend available for: $Text"
}

function New-PlayerEntry {
    param(
        [string]$WavePath,
        [int]$LifetimeMs = 500,
        [int]$Pan = 0,
        [int]$Volume = 100
    )

    if (-not (Test-Path $WavePath)) {
        Write-BridgeLog "Missing wave file: $WavePath"
        return
    }

    $rawBytes = [System.IO.File]::ReadAllBytes($WavePath)
    $wavBytes = [WavePan]::Pan16BitPcm($rawBytes, $Pan, $Volume)
    $stream = New-Object System.IO.MemoryStream(,$wavBytes)
    $player = New-Object System.Media.SoundPlayer($stream)
    $entry = [pscustomobject]@{
        WavePath = $WavePath
        Stream = $stream
        Player = $player
        ExpiresAt = [DateTime]::UtcNow.AddMilliseconds($LifetimeMs)
    }
    [void]$activePlayers.Add($entry)
    $activeWaveExpirations[$WavePath] = $entry.ExpiresAt
    $player.Play()
}

function Cleanup-Players {
    for ($i = $activePlayers.Count - 1; $i -ge 0; $i--) {
        $entry = $activePlayers[$i]
        if ([DateTime]::UtcNow -ge $entry.ExpiresAt) {
            if ($entry.PSObject.Properties['WavePath']) {
                $wavePath = [string]$entry.WavePath
                if ($activeWaveExpirations.ContainsKey($wavePath) -and $activeWaveExpirations[$wavePath] -le [DateTime]::UtcNow) {
                    $activeWaveExpirations.Remove($wavePath)
                }
            }
            try { $entry.Player.Stop() } catch {}
            try { $entry.Stream.Dispose() } catch {}
            $activePlayers.RemoveAt($i)
        }
    }
}

function Stop-LoopingPlayer {
    param([string]$WavePath)

    if (-not $loopingPlayers.ContainsKey($WavePath)) {
        return
    }

    $entry = $loopingPlayers[$WavePath]
    try { $entry.Player.Stop() } catch { Write-BridgeLog "Loop stop failed for ${WavePath}: $($_.Exception.Message)" }
    try { $entry.Stream.Dispose() } catch { Write-BridgeLog "Loop dispose failed for ${WavePath}: $($_.Exception.Message)" }
    $loopingPlayers.Remove($WavePath)
}

function Start-LoopingPlayer {
    param(
        [string]$WavePath,
        [int]$Pan = 0
    )

    if (-not (Test-Path $WavePath)) {
        Write-BridgeLog "Missing loop wave file: $WavePath"
        return
    }

    if ($loopingPlayers.ContainsKey($WavePath)) {
        return
    }

    try {
        $stream = [System.IO.File]::Open($WavePath, [System.IO.FileMode]::Open, [System.IO.FileAccess]::Read, [System.IO.FileShare]::ReadWrite)
        $player = New-Object System.Media.SoundPlayer($stream)
        $entry = [pscustomobject]@{
            Stream = $stream
            Player = $player
        }
        $loopingPlayers[$WavePath] = $entry
        $player.PlayLooping()
        Write-BridgeLog "Loop player started: $(Split-Path $WavePath -Leaf)"
    } catch {
        Write-BridgeLog "Loop player start failed for ${WavePath}: $($_.Exception.Message)"
    }
}

function Handle-SoundCommand {
    param([string[]]$Parts)

    if (-not $Parts -or $Parts.Count -eq 0) {
        return
    }

    switch ($Parts[0]) {
        'reset' {
            foreach ($wavePath in @($loopingPlayers.Keys)) {
                Stop-LoopingPlayer $wavePath
            }
            Write-BridgeLog 'Reset sound state.'
        }
        'play' {
            if ($Parts.Count -ge 2) {
                $waveName = $Parts[1]
                $wavePath = Join-Path $SoundsDir $waveName
                $lifetimeMs = 500
                $pan = 0
                $volume = 100
                if ($Parts.Count -ge 3) {
                    $parsedLifetime = 0
                    if ([int]::TryParse($Parts[2], [ref]$parsedLifetime) -and $parsedLifetime -gt 0) {
                        $lifetimeMs = $parsedLifetime
                    }
                }
                if ($Parts.Count -ge 4) {
                    $parsedPan = 0
                    if ([int]::TryParse($Parts[3], [ref]$parsedPan)) {
                        $pan = [Math]::Max(-100, [Math]::Min(100, $parsedPan))
                    }
                }
                if ($Parts.Count -ge 5) {
                    $parsedVolume = 100
                    if ([int]::TryParse($Parts[4], [ref]$parsedVolume)) {
                        $volume = [Math]::Max(0, [Math]::Min(100, $parsedVolume))
                    }
                }

                if ($activeWaveExpirations.ContainsKey($wavePath) -and $activeWaveExpirations[$wavePath] -gt [DateTime]::UtcNow) {
                    Write-BridgeLog "Skipped overlapping sound: $waveName"
                    return
                }

                if ($volume -le 0) {
                    return
                }

                New-PlayerEntry -WavePath $wavePath -LifetimeMs $lifetimeMs -Pan $pan -Volume $volume
                Write-BridgeLog "Play request: $waveName pan=$pan volume=$volume"
            }
        }
        'synth_step' {
            $pan = 0
            $variant = 0
            $pitchScale = 1.0
            $volume = 100
            if ($Parts.Count -ge 2) {
                $parsedPan = 0
                if ([int]::TryParse($Parts[1], [ref]$parsedPan)) {
                    $pan = [Math]::Max(-100, [Math]::Min(100, $parsedPan))
                }
            }
            if ($Parts.Count -ge 3) {
                $parsedVariant = 0
                if ([int]::TryParse($Parts[2], [ref]$parsedVariant)) {
                    $variant = [Math]::Abs($parsedVariant % 2)
                }
            }
            if ($Parts.Count -ge 4) {
                $parsedPitchScale = 1.0
                if ([double]::TryParse($Parts[3], [ref]$parsedPitchScale)) {
                    $pitchScale = [Math]::Max(0.333, [Math]::Min(3.0, $parsedPitchScale))
                }
            }
            if ($Parts.Count -ge 5) {
                $parsedVolume = 100
                if ([int]::TryParse($Parts[4], [ref]$parsedVolume)) {
                    $volume = [Math]::Max(0, [Math]::Min(100, $parsedVolume))
                }
            }
            $waveKey = "__synth_step__$pan`_$variant"
            if ($activeWaveExpirations.ContainsKey($waveKey) -and $activeWaveExpirations[$waveKey] -gt [DateTime]::UtcNow) {
                return
            }
            if ($volume -le 0) {
                return
            }
            $wavBytes = [StepSynth]::CreateStep($pan, $variant, $pitchScale, $volume)
            $stream = New-Object System.IO.MemoryStream(,$wavBytes)
            $player = New-Object System.Media.SoundPlayer($stream)
            $entry = [pscustomobject]@{
                WavePath = $waveKey
                Stream = $stream
                Player = $player
                ExpiresAt = [DateTime]::UtcNow.AddMilliseconds(120)
            }
            [void]$activePlayers.Add($entry)
            $activeWaveExpirations[$waveKey] = $entry.ExpiresAt
            $player.Play()
            Write-BridgeLog "Synth step pan=$pan variant=$variant pitch=$pitchScale volume=$volume"
        }
        'synth_bump' {
            $pan = 0
            $volume = 100
            if ($Parts.Count -ge 2) {
                $parsedPan = 0
                if ([int]::TryParse($Parts[1], [ref]$parsedPan)) {
                    $pan = [Math]::Max(-100, [Math]::Min(100, $parsedPan))
                }
            }
            if ($Parts.Count -ge 3) {
                $parsedVolume = 100
                if ([int]::TryParse($Parts[2], [ref]$parsedVolume)) {
                    $volume = [Math]::Max(0, [Math]::Min(100, $parsedVolume))
                }
            }
            $waveKey = "__synth_bump__$pan`_$volume"
            if ($activeWaveExpirations.ContainsKey($waveKey) -and $activeWaveExpirations[$waveKey] -gt [DateTime]::UtcNow) {
                return
            }
            if ($volume -le 0) {
                return
            }
            $wavBytes = [BumpSynth]::CreateBump($pan, $volume)
            $stream = New-Object System.IO.MemoryStream(,$wavBytes)
            $player = New-Object System.Media.SoundPlayer($stream)
            $entry = [pscustomobject]@{
                WavePath = $waveKey
                Stream = $stream
                Player = $player
                ExpiresAt = [DateTime]::UtcNow.AddMilliseconds(140)
            }
            [void]$activePlayers.Add($entry)
            $activeWaveExpirations[$waveKey] = $entry.ExpiresAt
            $player.Play()
            Write-BridgeLog "Synth bump pan=$pan volume=$volume"
        }
        'synth_enemy' {
            $pan = 0
            $pitchScale = 1.0
            $volume = 100
            if ($Parts.Count -ge 2) {
                $parsedPan = 0
                if ([int]::TryParse($Parts[1], [ref]$parsedPan)) {
                    $pan = [Math]::Max(-100, [Math]::Min(100, $parsedPan))
                }
            }
            if ($Parts.Count -ge 3) {
                $parsedPitchScale = 1.0
                if ([double]::TryParse($Parts[2], [ref]$parsedPitchScale)) {
                    $pitchScale = [Math]::Max(0.35, [Math]::Min(2.5, $parsedPitchScale))
                }
            }
            if ($Parts.Count -ge 4) {
                $parsedVolume = 100
                if ([int]::TryParse($Parts[3], [ref]$parsedVolume)) {
                    $volume = [Math]::Max(0, [Math]::Min(100, $parsedVolume))
                }
            }
            $waveKey = "__synth_enemy__$pan`_$pitchScale`_$volume"
            if ($activeWaveExpirations.ContainsKey($waveKey) -and $activeWaveExpirations[$waveKey] -gt [DateTime]::UtcNow) {
                return
            }
            if ($volume -le 0) {
                return
            }
            $wavBytes = [EnemySynth]::CreateEnemy($pan, $pitchScale, $volume)
            $stream = New-Object System.IO.MemoryStream(,$wavBytes)
            $player = New-Object System.Media.SoundPlayer($stream)
            $entry = [pscustomobject]@{
                WavePath = $waveKey
                Stream = $stream
                Player = $player
                ExpiresAt = [DateTime]::UtcNow.AddMilliseconds(180)
            }
            [void]$activePlayers.Add($entry)
            $activeWaveExpirations[$waveKey] = $entry.ExpiresAt
            $player.Play()
            Write-BridgeLog "Synth enemy pan=$pan pitch=$pitchScale volume=$volume"
        }
        'synth_item' {
            $pan = 0
            $itemId = 0
            $volume = 100
            if ($Parts.Count -ge 2) {
                $parsedPan = 0
                if ([int]::TryParse($Parts[1], [ref]$parsedPan)) {
                    $pan = [Math]::Max(-100, [Math]::Min(100, $parsedPan))
                }
            }
            if ($Parts.Count -ge 3) {
                $parsedItemId = 0
                if ([int]::TryParse($Parts[2], [ref]$parsedItemId)) {
                    $itemId = [Math]::Max(0, [Math]::Min(255, $parsedItemId))
                }
            }
            if ($Parts.Count -ge 4) {
                $parsedVolume = 100
                if ([int]::TryParse($Parts[3], [ref]$parsedVolume)) {
                    $volume = [Math]::Max(0, [Math]::Min(100, $parsedVolume))
                }
            }
            $waveKey = "__synth_item__$pan`_$itemId`_$volume"
            if ($activeWaveExpirations.ContainsKey($waveKey) -and $activeWaveExpirations[$waveKey] -gt [DateTime]::UtcNow) {
                return
            }
            if ($volume -le 0) {
                return
            }
            $wavBytes = [ItemSynth]::CreateItem($pan, $itemId, $volume)
            $stream = New-Object System.IO.MemoryStream(,$wavBytes)
            $player = New-Object System.Media.SoundPlayer($stream)
            $entry = [pscustomobject]@{
                WavePath = $waveKey
                Stream = $stream
                Player = $player
                ExpiresAt = [DateTime]::UtcNow.AddMilliseconds(180)
            }
            [void]$activePlayers.Add($entry)
            $activeWaveExpirations[$waveKey] = $entry.ExpiresAt
            $player.Play()
            Write-BridgeLog "Synth item pan=$pan item=$itemId volume=$volume"
        }
        'loop' {
            if ($Parts.Count -ge 2) {
                $waveName = $Parts[1]
                $wavePath = Join-Path $SoundsDir $waveName
                Start-LoopingPlayer $wavePath
                Write-BridgeLog "Loop request: $waveName"
            }
        }
        'stop_loop' {
            if ($Parts.Count -ge 2) {
                $waveName = $Parts[1]
                $wavePath = Join-Path $SoundsDir $waveName
                foreach ($existingKey in @($loopingPlayers.Keys)) {
                    if ($existingKey -like "$wavePath|*") {
                        Stop-LoopingPlayer $existingKey
                    }
                }
                Write-BridgeLog "Stop loop request: $waveName"
            }
        }
    }
}

if (-not (Test-Path $SpeechFile)) {
    Set-Content -Encoding UTF8 $SpeechFile '0|Sound bridge ready.'
}
if (-not (Test-Path $SoundCommandFile)) {
    Set-Content -Encoding UTF8 $SoundCommandFile ''
}
Set-Content -Encoding UTF8 $LogFile ''
Set-Content -Encoding UTF8 $SoundCommandFile ''

Write-BridgeLog "Sound bridge watching $SpeechFile"
Write-BridgeLog "Sound command file: $SoundCommandFile"
Write-BridgeLog "Sounds directory: $SoundsDir"
Write-BridgeLog "Backends: NVDA loaded=$nvdaLoaded, Tolk loaded=$tolkLoaded, Tolk ready=$tolkReady, Synth ready=$($null -ne $synth)"
Speak-Bridge 'Sound bridge ready.'

try {
    while ($true) {
        Cleanup-Players

        if (Test-Path $SpeechFile) {
            $payload = Get-Content $SpeechFile -Raw -ErrorAction SilentlyContinue
            if ($payload -and $payload -ne $lastSpeechPayload) {
                $lastSpeechPayload = $payload
                $trimmed = $payload.Trim()
                if ($trimmed -match '^(\d+)\|(.*)$') {
                    $sequence = [int]$matches[1]
                    $message = $matches[2].Trim()
                    if ($sequence -lt $lastSpeechSequence) {
                        Write-BridgeLog "Speech sequence reset detected: $sequence after $lastSpeechSequence"
                        $lastSpeechSequence = -1
                    }
                    if ($sequence -ne $lastSpeechSequence -and -not [string]::IsNullOrWhiteSpace($message)) {
                        $lastSpeechSequence = $sequence
                        Speak-Bridge $message
                    }
                }
            }
        }

        if (Test-Path $SoundCommandFile) {
            $lines = Get-Content $SoundCommandFile -ErrorAction SilentlyContinue
            if ($lines) {
                foreach ($line in $lines) {
                    $trimmed = [string]$line
                    if ([string]::IsNullOrWhiteSpace($trimmed)) {
                        continue
                    }

                    if ($trimmed -match '^(\d+)\|(.*)$') {
                        $sequence = [int]$matches[1]
                        $commandText = $matches[2].Trim()
                        if ($sequence -lt $lastSoundSequence) {
                            Write-BridgeLog "Sound sequence reset detected: $sequence after $lastSoundSequence"
                            $lastSoundSequence = -1
                        }
                        if ($sequence -gt $lastSoundSequence -and -not [string]::IsNullOrWhiteSpace($commandText)) {
                            $lastSoundSequence = $sequence
                            $parts = $commandText -split '\|'
                            Handle-SoundCommand -Parts $parts
                        }
                    }
                }

                $remainingLines = @()
                foreach ($line in $lines) {
                    $trimmed = [string]$line
                    if ($trimmed -match '^(\d+)\|') {
                        $sequence = [int]$matches[1]
                        if ($sequence -gt $lastSoundSequence) {
                            $remainingLines += $trimmed
                        }
                    }
                }

                Set-Content -Encoding UTF8 $SoundCommandFile $remainingLines
            }
        }

        Start-Sleep -Milliseconds $PollMs
    }
}
finally {
    foreach ($wavePath in @($loopingPlayers.Keys)) {
        Stop-LoopingPlayer $wavePath
    }
    if ($tolkLoaded -and $tolkReady) {
        try {
            [void][TolkBridge]::Tolk_Unload()
        } catch {
        }
    }
    if ($bridgeMutex) {
        try {
            [void]$bridgeMutex.ReleaseMutex()
        } catch {
        }
        try {
            $bridgeMutex.Dispose()
        } catch {
        }
    }
}
